$(function () {
    $('.tab>li>a').click(function () {
        $(this).parent().addClass('active').silblings().removeClass('active')
        return false;
    });
});

$('.notice li:first').click(function () {
    $('#modal').addClass('active');


});